//
//  ImageCollectionViewCell.swift
//  StudentInformationExchange
//
//  Created by Macbook-Pro on 16/12/23.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var designableView: DesignableView!
    
}
