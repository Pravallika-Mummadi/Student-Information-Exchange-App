//
//  HomeModel.swift
//  StudentInformationExchange
//
//  Created by Macbook-Pro on 29/11/23.
//

import Foundation
import UIKit

