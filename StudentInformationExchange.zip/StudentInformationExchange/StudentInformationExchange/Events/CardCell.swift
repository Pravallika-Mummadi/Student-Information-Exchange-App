 
import UIKit

class CardCell: UICollectionViewCell {

    @IBOutlet weak var cardImage: UIImageView!
    

}
